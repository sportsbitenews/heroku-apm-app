﻿
namespace SofttrendsAddon.ViewModels
{
    public class AccountOrganization
    {
        public string name { get; set; }
    }
}
